## GKE Basics

Oh hi! These files are used for hands-on labs in the GKE Basics course on [acloud.guru](https://acloud.guru/).
